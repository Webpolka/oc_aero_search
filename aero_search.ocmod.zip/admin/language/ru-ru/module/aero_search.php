<?php

// Heading Goes here:
$_['heading_title']            = 'Aero Search';

// Text
$_['text_extension']   		   = 'Расширения';
$_['text_edit']                = 'Редактировать модуль';
$_['text_success']             = 'Успешно: Вы модифицировали Aero Search модуль !';
$_['text_view_all_results']    = 'Показать все результаты';

// Multi language
$_['text_view_all_results_1'] = 'View all results';
$_['text_view_all_results_2'] = 'Показать все результаты';

// Entry
$_['entry_limit']              = 'Лимит поиска';
$_['entry_width']              = 'Ширина изображения товара';
$_['entry_height']             = 'Высота изображения товара';
$_['entry_title_length']       = 'Количество символов "Название товара"';
$_['entry_description_length'] = 'Количество символов "Описание товара"';
$_['entry_show_image']         = 'Показывать изображение товара';
$_['entry_show_price']         = 'Показывать цену';
$_['entry_show_description']   = 'Показать описание';
$_['entry_show_add_button']    = 'Показывать кнопку "Добавить в корзину"';
$_['entry_status']             = 'Статус';
$_['entry_view_all_results']   = 'Текст для кнопки: "Показать все результаты" ';
$_['entry_min_length']   	   = 'Минимальная длина ввода для срабатывании поиска';
$_['entry_show_rating']   	   = 'Показывать рейтинг';

// Help
$_['help_length']              = 'Показывать \'...\' когда количество символов больше, чем заданно.';
$_['help_view_all_results']    = 'Текстовая ссылка в нижней части результатов поиска';

// Error
$_['error_permission']         = 'Внимание: У вас нет прав на редактирование Aero Search модуля !';
$_['error_limit']              = 'Требуется указать лимит поиска!';
$_['error_width']              = 'Требуется указать ширину картинки товара!';
$_['error_height']             = 'Требуется указать высоту картинки товара!';
$_['error_title_length']       = 'Требуется указать количество символов "Название товара" !';
$_['error_description_length'] = 'Требуется указать количество символов "Описание товара" !';
$_['error_view_all_results']   = 'Поле "Посмотреть все результаты" обязателено к заполнению !';
$_['error_min_length']   	   = 'Минимальная длина поиска обязательна !';
?>
